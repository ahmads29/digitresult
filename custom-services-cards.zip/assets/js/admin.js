jQuery(document).ready(function($) {
    // Image upload
    $('.csc-upload-image').click(function(e) {
        e.preventDefault();
        
        var button = $(this);
        var imageUrlInput = button.siblings('input[type="text"]');
        
        var frame = wp.media({
            title: 'Select or Upload Image',
            button: {
                text: 'Use this image'
            },
            multiple: false
        });
        
        frame.on('select', function() {
            var attachment = frame.state().get('selection').first().toJSON();
            imageUrlInput.val(attachment.url);
            
            // Show preview
            var preview = button.siblings('.csc-image-preview');
            if (preview.length === 0) {
                preview = $('<div class="csc-image-preview"></div>');
                button.after(preview);
            }
            preview.html('<img src="' + attachment.url + '" style="max-width: 200px; height: auto;">');
        });
        
        frame.open();
    });
    
    // Make cards sortable
    if ($('#csc-sortable-cards').length) {
        $('#csc-sortable-cards').sortable({
            handle: '.csc-handle',
            placeholder: 'ui-sortable-placeholder',
            axis: 'y',
            update: function(event, ui) {
                var order = [];
                $('#csc-sortable-cards tr').each(function() {
                    order.push($(this).data('id'));
                });
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'csc_update_card_order',
                        order: order,
                        security: $('#csc_card_order_nonce').val()
                    },
                    success: function(response) {
                        if (!response.success) {
                            console.log('Error updating order');
                        }
                    }
                });
            }
        });
    }
    
    // Add nonce for card ordering
    $('form').append('<input type="hidden" id="csc_card_order_nonce" name="csc_card_order_nonce" value="' + csc_admin_vars.nonce + '">');
});