(function() {
    tinymce.PluginManager.add('csc_shortcode', function(editor, url) {
        editor.addButton('csc_shortcode_button', {
            title: 'Insert Service Cards',
            icon: 'icon dashicons-images-alt2',
            onclick: function() {
                editor.windowManager.open({
                    title: 'Insert Service Cards',
                    body: [
                        {
                            type: 'listbox',
                            name: 'columns',
                            label: 'Columns per row',
                            values: [
                                {text: '1 Column', value: '1'},
                                {text: '2 Columns', value: '2'},
                                {text: '3 Columns', value: '3'},
                                {text: '4 Columns', value: '4'}
                            ]
                        },
                        {
                            type: 'listbox',
                            name: 'style',
                            label: 'Card Style',
                            values: [
                                {text: 'Default', value: 'default'},
                                {text: 'Minimal', value: 'minimal'},
                                {text: 'Modern', value: 'modern'}
                            ]
                        }
                    ],
                    onsubmit: function(e) {
                        editor.insertContent('[custom_service_cards columns="' + e.data.columns + '" style="' + e.data.style + '"]');
                    }
                });
            }
        });
    });
})();