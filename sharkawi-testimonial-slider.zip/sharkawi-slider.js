document.addEventListener("DOMContentLoaded", function () {
    const slider = document.querySelector(".sharkawi-slider");
    const prevBtn = document.querySelector(".sharkawi-prev");
    const nextBtn = document.querySelector(".sharkawi-next");
    const items = document.querySelectorAll(".testimonial-container");
    const totalItems = items.length;
    let index = 0;
  
    function showSlide(i) {
      slider.style.transform = `translateX(-${i * 52}%)`;
    }
  
    function nextSlide() {
      index = (index + 1) % totalItems;
      showSlide(index);
    }
  
    function prevSlide() {
      index = (index - 1 + totalItems) % totalItems;
      showSlide(index);
    }
  
    nextBtn.addEventListener("click", nextSlide);
    prevBtn.addEventListener("click", prevSlide);
  
    setInterval(nextSlide, 3000); // auto-slide every 3s
  });
  