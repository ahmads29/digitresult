<?php
/*
Plugin Name: Sharkawi Testimonial Slider
Description: A testimonial slider plugin developed by Ahmad Sharkawi.
Version: 1.0
Author: Ahmad Sharkawi
*/

if (!defined('ABSPATH')) exit;

// Register Custom Post Type
function sharkawi_register_testimonial_post_type() {
    register_post_type('sharkawi_testimonial', [
        'labels' => [
            'name' => 'Testimonials',
            'singular_name' => 'Testimonial',
        ],
        'public' => true,
        'menu_icon' => 'dashicons-testimonial',
        'supports' => ['title', 'editor', 'thumbnail'],
    ]);
}
add_action('init', 'sharkawi_register_testimonial_post_type');

// Enqueue Scripts & Styles
function sharkawi_enqueue_slider_assets() {
    wp_enqueue_style('sharkawi-slider-style', plugin_dir_url(__FILE__) . 'style.css');
    wp_enqueue_script('sharkawi-slider-script', plugin_dir_url(__FILE__) . 'sharkawi-slider.js', ['jquery'], false, true);
}
add_action('wp_enqueue_scripts', 'sharkawi_enqueue_slider_assets');

// Shortcode to render slider
function sharkawi_testimonial_slider_shortcode() {
    $args = [
        'post_type' => 'sharkawi_testimonial',
        'posts_per_page' => -1
    ];
    $testimonials = new WP_Query($args);

    ob_start();
    ?>
    <div class="sharkawi-slider-wrapper">
        <button class="sharkawi-prev">&lt;</button>
        <div class="sharkawi-slider">
            <?php while ($testimonials->have_posts()) : $testimonials->the_post(); ?>
                <div class="testimonial-container">
                    <img src="http://as.digitresults.com/wp-content/uploads/2025/06/quote-a-right-svgrepo-com-1-1.png" alt="" />
                    <p><?php the_content(); ?></p>
                    <hr>
                    <div class="sharkawi_testimonial">
                        <?php if (has_post_thumbnail()) : ?>
                            <?php the_post_thumbnail('thumbnail'); ?>
                        <?php endif; ?>
                        <div class="testimonial-rating">
                            <img src="http://as.digitresults.com/wp-content/uploads/2025/06/Frame-1261159130.png">
                            <p class="testimonial-name"><?php the_title(); ?></p>
                        </div>
                    </div>
                </div>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
        <button class="sharkawi-next">&gt;</button>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('sharkawi_testimonials', 'sharkawi_testimonial_slider_shortcode');
